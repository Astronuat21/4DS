G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-08-08T15:06:31-04:00*
G04 #@! TF.ProjectId,CTRL_PWR,4354524c-5f50-4575-922e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-08 15:06:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.070000X1.800000*%
%ADD11O,1.070000X1.800000*%
%ADD12RoundRect,0.147500X0.172500X-0.147500X0.172500X0.147500X-0.172500X0.147500X-0.172500X-0.147500X0*%
%ADD13R,1.550000X1.300000*%
%ADD14C,2.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D3*
X93645000Y-114235000D03*
D11*
X92375000Y-114235000D03*
X91105000Y-114235000D03*
X89835000Y-114235000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D21*
X87850000Y-116585000D03*
X87850000Y-115615000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,S1*
X84895000Y-116468000D03*
X76945000Y-116468000D03*
X84895000Y-111968000D03*
X76945000Y-111968000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,H1*
X79089000Y-105981000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,D4*
X100260000Y-114250000D03*
D11*
X98990000Y-114250000D03*
X97720000Y-114250000D03*
X96450000Y-114250000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,H2*
X105089000Y-114981000D03*
G04 #@! TD*
M02*
